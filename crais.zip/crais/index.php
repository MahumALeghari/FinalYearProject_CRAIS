<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRAIS</title>
    <link rel="stylesheet" href="css/my_test_phase.css">
</head>

<body>

    <div class="topnavibar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="officers_registration.php">Investigation Officer / Senior Officer</a></li>
            <li><a href="informer_registration.php">Informer / Reporter</a></li>
            <li><a href="about_us_page.php">About Us</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>


    <h1><b>Your Security Our Priority</b></h1>
    <input class="homepagesearch" type="text" placeholder="Search..">

    <div class="SmallerOne">
        <P><b>AWARENESS CAMPAIGNS</b></P>
        <button><a href="#">OPEN</a></button>
    </div>
    <div class="AnotherSmallerOne">
        <p><b>CRIME NEWS</b></p>
        <button><a href="#">OPEN</a></button>
    </div>
    <div class="LargerOne">
        <p> We encourage all citizens to get involved by reporting suspicious circumstances, about lost items and by cooperating with police officers with staying up-to-date with all the awareness campaigns. We believe in providing quality services with the
            highest possible degree of excellence. It is Advised to contact us with the button below in case of any emergency. <br>Thankyou. </p>

        <button><a href="contact_us.php">Contact Us</a></button>
    </div>

</body>

</html>