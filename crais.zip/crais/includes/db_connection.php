<?php



// $host = "localhost";
// $username = "root";
// $password = "";
// $dbname = "mynewdb";


$connection = mysqli_connect("localhost", "root", "", "mynewdb");

if(!$connection){
    echo "DB_Connection Failed!";
}
















/*

$fname      = $_GET['fname'];
$lname      = $_GET['lname'];
$emailid    = $_GET['emailid'];
$PhoneNumber  = $_GET['conNumber'];
$Address    = $_GETT['AddressDetails'];
$PWD       = $_GET['Pass'];

// database connection

$conn = new mysqli ('locat host', 'root', ' ', 'entry.details');
if($conn->connect_error){
    die('connection failed : '. $conn->connect_error);
}
else
 {
    $stmt = $conn->prepare("insert into investo(fname, lname, emailid, conNumber, AddressDetails, Pass) values(?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi",$fname, $lname, $emailid, $PhoneNumber, $Address, $PWD);
    $stmt->execute();
    echo " registration successfully..";
    $stmt->close();
    $conn-> close();

}
*/





?>