-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2022 at 06:42 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mynewdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `crimesc`
--

CREATE TABLE `crimesc` (
  `crime_id` int(11) NOT NULL,
  `crime_informer_name` varchar(100) NOT NULL,
  `crime_informer_mobile` varchar(100) NOT NULL,
  `crime_type` varchar(100) NOT NULL,
  `crime_date` date NOT NULL,
  `crime_time` time NOT NULL,
  `crime_location` varchar(100) NOT NULL,
  `crime_informer_message` text NOT NULL,
  `crime_file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crimesc`
--

INSERT INTO `crimesc` (`crime_id`, `crime_informer_name`, `crime_informer_mobile`, `crime_type`, `crime_date`, `crime_time`, `crime_location`, `crime_informer_message`, `crime_file`) VALUES
(2, 'Asif', '03001234556', 'False Imprisonment', '2022-11-23', '22:07:00', 'Mirpur', 'I have attached an important picture.', 'Screenshot (23).png'),
(3, 'Uzair', '03112233444', 'Drug Crimes', '2022-11-21', '14:38:00', 'Mirpur', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `informer`
--

CREATE TABLE `informer` (
  `informer_id` int(11) NOT NULL,
  `informer_name` varchar(100) NOT NULL,
  `informer_father_name` varchar(100) NOT NULL,
  `informer_email` varchar(100) NOT NULL,
  `informer_mobile` varchar(100) NOT NULL,
  `informer_address` text NOT NULL,
  `informer_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `informer`
--

INSERT INTO `informer` (`informer_id`, `informer_name`, `informer_father_name`, `informer_email`, `informer_mobile`, `informer_address`, `informer_password`) VALUES
(1, 'Asif', 'Hanif', 'asif123@gmail.com', '03001234556', 'Mirpur AJ&K', '12345'),
(3, 'Uzair', 'Shakeel', 'uzair123@gmail.com', '03112233444', 'Mirpur AJ&K', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `officers`
--

CREATE TABLE `officers` (
  `officer_id` int(11) NOT NULL,
  `officer_name` varchar(100) NOT NULL,
  `officer_father_name` varchar(100) NOT NULL,
  `officer_rank` varchar(100) NOT NULL,
  `officer_email` varchar(100) NOT NULL,
  `officer_mobile` varchar(100) NOT NULL,
  `officer_address` text NOT NULL,
  `officer_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `officers`
--

INSERT INTO `officers` (`officer_id`, `officer_name`, `officer_father_name`, `officer_rank`, `officer_email`, `officer_mobile`, `officer_address`, `officer_password`) VALUES
(2, 'Muhammad Aleem', 'Muhammad Amin Hashmi', 'Investigation Officer', 'aleemhashmi4321@gmail.com', '03445387545', 'Mirpur AJ&K', '12345'),
(3, 'Muhammad Azeem', 'Muhammad Amin Hashmi', 'Senior Officer', 'azeem@gmail.com', '03445387545', 'Mirpur AJ&K', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crimesc`
--
ALTER TABLE `crimesc`
  ADD PRIMARY KEY (`crime_id`);

--
-- Indexes for table `informer`
--
ALTER TABLE `informer`
  ADD PRIMARY KEY (`informer_id`);

--
-- Indexes for table `officers`
--
ALTER TABLE `officers`
  ADD PRIMARY KEY (`officer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crimesc`
--
ALTER TABLE `crimesc`
  MODIFY `crime_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `informer`
--
ALTER TABLE `informer`
  MODIFY `informer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `officers`
--
ALTER TABLE `officers`
  MODIFY `officer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
