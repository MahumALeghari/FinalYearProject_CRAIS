<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp Page</title>
    <link rel="stylesheet" href="css/my_test_phase_2.css">
</head>

<body style="background-image: url('images/officers_registration.jpg'); background-size: cover;">

    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>

    <div class="movetologin">
        <a href="login.php">Login</a>
    </div>

    <h1>REGISTRATION FORM</h1>
    <div class="main">
        <div class="register">

            <?php 

                include 'includes/db_connection.php';

                if (isset($_POST['submit'])) {
                    $informer_name = $_POST['informer_name'];
                    $informer_father_name = $_POST['informer_father_name'];
                    $informer_email = $_POST['informer_email'];
                    $informer_mobile = $_POST['informer_mobile'];
                    $informer_address = $_POST['informer_address'];
                    $informer_password = $_POST['informer_password'];

                    $query = "INSERT INTO informer (informer_name, informer_father_name, informer_email, informer_mobile, informer_address, informer_password) VALUES ('$informer_name', '$informer_father_name', '$informer_email', '$informer_mobile', '$informer_address', '$informer_password')";


                    if (!$query) {
                        die("Query Failed!");
                    }

                    $result = mysqli_query($connection, $query);

                    if ($result) {
                        echo "<div class='alert alert-success'>Data Uploaded Successfully!</div>";   
                    } else {
                        die("Query Connection Failed! " . mysqli_error($connection));
                    }

                }

            ?>

            <form action="" method="POST" enctype="multipart/form-data">

                <br>
                <label>First Name</label>
                <br>
                <input type="text" name="informer_name" placeholder="Enter your Name">
                <br><br>

                <label>Last Name</label>
                <br>
                <input type="text" name="informer_father_name" placeholder="Enter your father name">
                <br><br>

                <label>Email ID</label>
                <br>
                <input type="email" name="informer_email" placeholder="Please enter your email address">
                <br><br>

                <label>Contact Number</label>
                <br>
                <input type="text" name="informer_mobile" placeholder="Enter mobile number">
                <br><br>

                <label>Address</label>
                <br>
                <textarea type="text" name="informer_address" placeholder="Please enter your address"></textarea>
                <br><br>

                <label>Password</label>
                <br>
                <input type="password" name="informer_password" placeholder="Create Password!">
                <br><br>
                <button type="submit" name="submit">Get yourself registered!</button>
                <br><br>

            </form>
        </div>
    </div>





</body>

</html>