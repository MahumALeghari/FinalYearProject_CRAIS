<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login for CRAIS</title>
    <!-- <link rel="stylesheet" href="css/my_test_phase_3.css"> -->
    <style>
        /* This is for Login */

        .homebuttonwork a {
            background-color: #111C82;
            color: aliceblue;
            font-family: Arial, Helvetica, sans-serif;
            font-size: large;
            position: relative;
            top: 2px;
            left: 40px;
            text-decoration: none;
        }

        body {
            background-color: #111C82;
        }

        .loginrectangle {
            background-color: white;
            width: 650px;
            position: relative;
            top: 80px;
            left: 25%;
            border-radius: 22px;
        }

        .loginrectangle input {
            position: relative;
            /* left: 135px;
            width: 360px;
            height: 50px; */
            border: 3px lightgray;
            background-color: lightgrey;
        }

        .loginrectangle a {
            background-color: rgb(11, 121, 11);
            color: white;
            display: block;
            text-align: center;
            text-decoration: none;
            position: relative;
            left: 138px;
            width: 297px;
            padding: 16px 31px;
        }

        .forlasthyperlink p a {
            font-family: Arial, Helvetica, sans-serif;
            color: rgb(0, 0, 0);
            font-size: 13pt;
            position: relative;
            top: -16px;
            left: 140px;
            background-color: white;
        }
    </style>
</head>

<body>
    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>


    <div class="forlasthyperlink">
        <div class="loginrectangle">

            <?php

                include 'includes/db_connection.php';

                if (isset($_POST['login'])) {

                    $user = $_POST['user'];
                    
                    switch ($user) {
                        
                        case 'informer':

                            $informer_email = $_POST['user_email'];
                            $informer_password = $_POST['user_password'];

                            $informer_email = mysqli_real_escape_string($connection, $informer_email);
                            $informer_password = mysqli_real_escape_string($connection, $informer_password);

                            $query = "SELECT * FROM informer WHERE informer_email = '$informer_email'";

                            if (!$query) {
                                die("Query Failed!" . mysqli_error($connection));
                            }

                            $query_conn = mysqli_query($connection, $query);
                            
                            if (!$query_conn) {
                                die("Connection Query Failed!" . mysqli_error($connection));
                            }

                            while ($row = mysqli_fetch_assoc($query_conn)) {
                                $db_informer_id = $row['informer_id'];
                                $db_informer_name = $row['informer_name'];
                                $db_informer_email = $row['informer_email'];
                                $db_informer_password = $row['informer_password'];
                            }

                            if ($informer_email == $db_informer_email && $informer_password == $db_informer_password) {

                                header("Location: welcome_informer.php");

                            } else {
                                header("Location: login.php");
                            }
                            
                            break;
                        
                        case 'investigation_officer':
                            
                            $officer_email = $_POST['user_email'];
                            $officer_password = $_POST['user_password'];

                            $officer_email = mysqli_real_escape_string($connection, $officer_email);
                            $officer_password = mysqli_real_escape_string($connection, $officer_password);

                            $query = "SELECT * FROM officers WHERE officer_email = '$officer_email'";

                            if (!$query) {
                                die("Query Failed!" . mysqli_error($connection));
                            }

                            $query_conn = mysqli_query($connection, $query);
                            
                            if (!$query_conn) {
                                die("Connection Query Failed!" . mysqli_error($connection));
                            }

                            while ($row = mysqli_fetch_assoc($query_conn)) {
                                $db_officer_id = $row['officer_id'];
                                $db_officer_name = $row['officer_name'];
                                $db_officer_email = $row['officer_email'];
                                $db_officer_password = $row['officer_password'];
                                $db_officer_rank = $row['officer_rank'];
                            }

                            if ($officer_email == $db_officer_email && $officer_password == $db_officer_password) {

                                header("Location: welcome_officer.php");

                            } else {
                                header("Location: login.php");
                            }
                            
                            break;

                        case 'senior_officer':
                            
                            $officer_email = $_POST['user_email'];
                            $officer_password = $_POST['user_password'];

                            $officer_email = mysqli_real_escape_string($connection, $officer_email);
                            $officer_password = mysqli_real_escape_string($connection, $officer_password);

                            $query = "SELECT * FROM officers WHERE officer_email = '$officer_email'";

                            if (!$query) {
                                die("Query Failed!" . mysqli_error($connection));
                            }

                            $query_conn = mysqli_query($connection, $query);
                            
                            if (!$query_conn) {
                                die("Connection Query Failed!" . mysqli_error($connection));
                            }

                            while ($row = mysqli_fetch_assoc($query_conn)) {
                                $db_officer_id = $row['officer_id'];
                                $db_officer_name = $row['officer_name'];
                                $db_officer_email = $row['officer_email'];
                                $db_officer_password = $row['officer_password'];
                                $db_officer_rank = $row['officer_rank'];
                            }

                            if ($officer_email == $db_officer_email && $officer_password == $db_officer_password) {

                                header("Location: welcome_officer.php");

                            } else {
                                header("Location: login.php");
                            }
                            
                            break;

                        default:
                            echo "<h6 class='alert alert-danger'>Please Enter Correct Data!</h6>";
                            break;
                    }

                }


            ?>
            <form action="" method="POST">
                
                <br> &nbsp
                <label for="users"><b>Select Role:</b></label>
                <br>
                <div style="display: flex; margin-left: 100px;">
                <input type="radio" name="user" value="informer">Informer/Reporter</input>
                <br>

                
                <input type="radio" name="user" value="investigation_officer">Investigation Officer</input>
                <br>

               
                <input type="radio" name="user" value="senior_officer">Senior Officer</input>
            </div>
                <br><br>
                <input style="margin-left: 150px; height: 45px; width: 300px;" type="email" name="user_email" placeholder="Enter Your Email" required>
                <br><br>
                <input style="margin-left: 150px; height: 45px; width: 300px;" type="password" name="user_password" placeholder="Enter Your Password" required>
                <br><br><br>
                
                <button type="submit" name="login" style="background-color: green; color: white; width: 200px; height: 45px; margin-left: 200px;">LOGIN</button>
                <br><br><br><br>

            </form>
        </div>
    </div>




</body>

</html>