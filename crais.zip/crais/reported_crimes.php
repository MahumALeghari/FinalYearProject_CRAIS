<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRAIS - REPORTED CRIMES</title>
    <Link rel="stylesheet" href="css/my_test_phase_4.css">
</head>

<body>
    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>

    <div class="gobackk">
        <a href="welcome_informer.php">Go Back</a>
    </div>
    <h1>REPORTED CRIMES</h1>

    <div class="container">
        <div class="insidecontainer">

            <?php 

                include 'includes/db_connection.php';

                if (isset($_POST['submit'])) {
                    $crime_informer_name = $_POST['crime_informer_name'];
                    $crime_informer_mobile = $_POST['crime_informer_mobile'];
                    $crime_type = $_POST['crime_type'];
                    $crime_date = $_POST['crime_date'];
                    $crime_time = $_POST['crime_time'];
                    $crime_location = $_POST['crime_location'];
                    $crime_informer_message = $_POST['crime_informer_message'];
                    $crime_file = $_FILES['crime_file']['name'];
                    $crime_file_tmp = $_FILES['crime_file']['tmp_name'];

                    move_uploaded_file($crime_file_tmp, "images/$crime_file");

                    $query = "INSERT INTO crimesc (crime_informer_name, crime_informer_mobile, crime_type, crime_date, crime_time, crime_location, crime_informer_message, crime_file) VALUES ('$crime_informer_name', '$crime_informer_mobile', '$crime_type', '$crime_date', '$crime_time', '$crime_location', '$crime_informer_message', '$crime_file')";


                    if (!$query) {
                    die("Query Failed!");
                    }

                    $result = mysqli_query($connection, $query);

                    if ($result) {
                    echo "<div class='alert alert-success'>Data Uploaded Successfully!</div>";   
                    } else {
                    die("Query Connection Failed! " . mysqli_error($connection));
                    }

                }

            ?>

                <table border="1px" style="color: white;">
                    <thead>
                        <td>Crime ID</td>
                        <td>Crime Informer</td>
                        <td>Informer Mobile</td>
                        <td>Type</td>
                        <td>Date</td>
                        <td>Time</td>
                        <td>Location</td>
                        <td>Description</td>
                        <td>File</td>
                    </thead>

                        <?php 

                            include 'includes/db_connection.php';

                            $query = "SELECT * FROM crimesc";
                            $query_conn = mysqli_query($connection, $query);
                            while ($result = mysqli_fetch_assoc($query_conn)) {
                                $crime_id = $result['crime_id'];
                                $crime_informer_name = $result['crime_informer_name'];
                                $crime_informer_mobile = $result['crime_informer_mobile'];
                                $crime_type = $result['crime_type'];
                                $crime_date = $result['crime_date'];
                                $crime_time = $result['crime_time'];
                                $crime_location = $result['crime_location'];
                                $crime_informer_message = $result['crime_informer_message'];
                                $crime_file = $result['crime_file'];

                        ?>

                    <tbody>

                        <td><?php echo $crime_id; ?></td>
                        <td><?php echo $crime_informer_name; ?></td>
                        <td><?php echo $crime_informer_mobile; ?></td>
                        <td><?php echo $crime_type; ?></td>
                        <td><?php echo $crime_date; ?></td>
                        <td><?php echo $crime_time; ?></td>
                        <td><?php echo $crime_location; ?></td>
                        <td><?php echo $crime_informer_message; ?></td>
                        <td><a href="images/<?php echo $crime_file; ?>" download>
                        <?php 

                          if (!empty($crime_file)) {
                            echo "<button>Download</button>";
                          }

                         ?>
                        </a></td>

                    </tbody>

                        <?php 

                            }

                        ?>
                        
                </table>



        </div>
    </div>

    <br><br><br>






</body>

</html>