<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome User</title>
    <link rel="stylesheet" href="css/my_test_phase_4.css">
</head>


<body>
    <br>
    <h1>DEAR OFFICER, WELCOME!</h1>
    <div class="hello">
        <table>
            <tr>
                <td><a href="report_crime.php">Report Crime</a></td>
                <td>Report Lost Item</td>
                <td>View Reports</td>
                <td><a href="index.php">Homepage</a></td>
            </tr>
        </table>


        <br><br><br>

        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Et magni iste ullam eum quod hic alias nulla voluptas tempore delectus, quibusdam accusantium ipsam cumque rerum provident reprehenderit illum veniam perferendis, possimus odio commodi
            reiciendis nesciunt libero? Nesciunt veritatis animi iure. Deserunt minus quas aperiam, accusantium molestiae, totam earum numquam explicabo sint similique dolorum omnis vel quisquam quibusdam maxime quia eos voluptatum inventore officia temporibus
            itaque. Nobis dolorum repudiandae facilis dolores tenetur qui aspernatur. Libero laborum odio hic eos eius commodi.</p>









</body>

</html>