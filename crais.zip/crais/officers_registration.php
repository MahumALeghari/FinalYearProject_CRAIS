<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officers Registration Form</title>
    <link rel="stylesheet" href="css/my_test_phase_2.css">
</head>



<body style="background-image: url('images/officers_registration.jpg'); background-size: cover;">

    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>

    <div class="movetologin">
        <a href="login.php">Login</a>
    </div>



    <h1>REGISTRATION FORM</h1>
    <div class="main">


        <div class="register">
            <br>

            <?php 

                include 'includes/db_connection.php';

                if (isset($_POST['submit'])) {

                    $register_officer = $_POST['register_officer'];
                    
                    switch ($register_officer) {
                        
                        case 'investigation_officer':

                            $officer_name = $_POST['officer_name'];
                            $officer_father_name = $_POST['officer_father_name'];
                            $officer_rank = "Investigation Officer";
                            $officer_email = $_POST['officer_email'];
                            $officer_mobile = $_POST['officer_mobile'];
                            $officer_address = $_POST['officer_address'];
                            $officer_password = $_POST['officer_password'];

                            $query = "INSERT INTO officers (officer_name, officer_father_name, officer_rank, officer_email, officer_mobile, officer_address, officer_password) VALUES ('$officer_name', '$officer_father_name', '$officer_rank', '$officer_email', '$officer_mobile', '$officer_address', '$officer_password')";


                            if (!$query) {
                                die("Query Failed!");
                            }

                            $result = mysqli_query($connection, $query);

                            if ($result) {
                                echo "<div class='alert alert-success'>Data Uploaded Successfully!</div>";   
                            } else {
                                die("Query Connection Failed! " . mysqli_error($connection));
                            }
                            
                            break;
                        
                        case 'senior_officer':
                            
                            $officer_name = $_POST['officer_name'];
                            $officer_father_name = $_POST['officer_father_name'];
                            $officer_rank = "Senior Officer";
                            $officer_email = $_POST['officer_email'];
                            $officer_mobile = $_POST['officer_mobile'];
                            $officer_address = $_POST['officer_address'];
                            $officer_password = $_POST['officer_password'];

                            $query = "INSERT INTO officers (officer_name, officer_father_name, officer_rank, officer_email, officer_mobile, officer_address, officer_password) VALUES ('$officer_name', '$officer_father_name', '$officer_rank', '$officer_email', '$officer_mobile', '$officer_address', '$officer_password')";

                            if (!$query) {
                                die("Query Failed!");
                            }

                            $result = mysqli_query($connection, $query);

                            if ($result) {
                                echo "<div class='alert alert-success'>Data Uploaded Successfully!</div>";   
                            } else {
                                die("Query Connection Failed! " . mysqli_error($connection));
                            }
                            
                            break;

                        default:
                            echo "<h6 class='alert alert-danger'>Please Enter Correct Data!</h6>";
                            break;
                    }

                }


            ?>


            <form action="" method="POST" enctype="multipart/form-data">

                <div style="display: flex;">

                <input type="radio" name="register_officer" value="investigation_officer">Investigation Officer</input>

                <input type="radio" name="register_officer" value="senior_officer">Senior Officer</input>

                </div>

                <input type="text" name="officer_name" placeholder="Enter your Name">

                <input type="text" name="officer_father_name" placeholder="Enter your father name">

                <input type="email" name="officer_email" placeholder="Please enter your email address">

                <input type="text" name="officer_mobile" placeholder="Enter phone number">

                <textarea type="text" name="officer_address" placeholder="Please enter your address"></textarea>

                <input type="password" name="officer_password" placeholder="Create Password!"><br>
                <br><br>
                <button type="submit" name="submit">Get Yourself Register</button>
                <br><br><br>

            </form>
        </div>
    </div>

</body>

</html>