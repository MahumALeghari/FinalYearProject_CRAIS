<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact us page</title>
    <link rel="stylesheet" href="css/my_test_phase.css">
</head>

<body>
    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>


    <h1>Contact us</h1>
    <div class="contactusbase">
        <h6><br>Please feel free to contact us!</h6>
        <p>Phone Number: +92-xxx-xxxxxxx / +92-xxx-xxxxxxx <br></p>
        <p>Email: dummyemail@gmail.com</p>
    </div>





</body>

</html>