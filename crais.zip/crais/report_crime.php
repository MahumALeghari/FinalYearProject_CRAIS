<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRAIS - REPORT CRIME</title>
    <Link rel="stylesheet" href="css/my_test_phase_4.css">
</head>

<body>
    <div class="homebuttonwork">
        <a href="index.php">Homepage</a>
    </div>

    <div class="gobackk">
        <a href="welcome_informer.php">Go Back</a>
    </div>
    <h1>REPORT CRIME</h1>

    <div class="container">
        <div class="insidecontainer">

            <?php 

                include 'includes/db_connection.php';

                if (isset($_POST['submit'])) {
                    $crime_informer_name = $_POST['crime_informer_name'];
                    $crime_informer_mobile = $_POST['crime_informer_mobile'];
                    $crime_type = $_POST['crime_type'];
                    $crime_date = $_POST['crime_date'];
                    $crime_time = $_POST['crime_time'];
                    $crime_location = $_POST['crime_location'];
                    $crime_informer_message = $_POST['crime_informer_message'];
                    $crime_file = $_FILES['crime_file']['name'];
                    $crime_file_tmp = $_FILES['crime_file']['tmp_name'];

                    move_uploaded_file($crime_file_tmp, "images/$crime_file");

                    $query = "INSERT INTO crimesc (crime_informer_name, crime_informer_mobile, crime_type, crime_date, crime_time, crime_location, crime_informer_message, crime_file) VALUES ('$crime_informer_name', '$crime_informer_mobile', '$crime_type', '$crime_date', '$crime_time', '$crime_location', '$crime_informer_message', '$crime_file')";


                    if (!$query) {
                    die("Query Failed!");
                    }

                    $result = mysqli_query($connection, $query);

                    if ($result) {
                    echo "<div class='alert alert-success'>Data Uploaded Successfully!</div>";   
                    } else {
                    die("Query Connection Failed! " . mysqli_error($connection));
                    }

                }

            ?>

            <form action="" method="POST" enctype="multipart/form-data">
                <br>
                <input type="text" name="crime_informer_name" placeholder="Name" style="color: black; !important"><br><br><br>
                <input type="text" name="crime_informer_mobile" placeholder="Mobile number" style="color: black; !important"><br><br>
                <select name="crime_type">
                    <option value="">Select</option>
                    <option value="Assualt">Assualt</option>
                    <option value="False Imprisonment">False Imprisonment</option>
                    <option value="Kidnapping">Kidnapping</option>    
                    <option value="Robbery">Robbery/Theft</option>
                    <option value="Murder">Murder</option>
                    <option value="Rape">Rape</option>
                    <option value="Drug Crimes">Drug Crimes</option>
                    <option value="Harassments">Harrasments</option>
                    <option value="Defamation">Defamation</option>
                </select><br><br><br>
                <input type="date" name="crime_date" placeholder="Date" style="color: black; !important"><br><br><br>
                <input type="time" name="crime_time" placeholder="Time" style="color: black; !important"><br><br><br>
                <input type="text" name="crime_location" placeholder="Location" style="color: black; !important"><br><br><br>
                
                <select name="cities">
                    <option value="">Select</option>
                    <option value="Lahore">lahore</option>
                    <option value="Karchi">Karachi</option>
                    <option value="Multan">Multan</option>    
                    <option value="Islamabad">Islamabad</option>
                </select><br><br><br>

                <textarea name="crime_informer_message" placeholder="   Your message"></textarea><br>
                <input type="file" id="myFile" name="crime_file">
                <br>

                <button type="submit" name="submit">Submit</button>


            </form>



        </div>
    </div>

    <br><br><br>






</body>

</html>